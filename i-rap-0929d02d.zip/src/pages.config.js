/**
 * pages.config.js - Page routing configuration
 * 
 * This file is AUTO-GENERATED. Do not add imports or modify PAGES manually.
 * Pages are auto-registered when you create files in the ./pages/ folder.
 * 
 * THE ONLY EDITABLE VALUE: mainPage
 * This controls which page is the landing page (shown when users visit the app).
 * 
 * Example file structure:
 * 
 *   import HomePage from './pages/HomePage';
 *   import Dashboard from './pages/Dashboard';
 *   import Settings from './pages/Settings';
 *   
 *   export const PAGES = {
 *       "HomePage": HomePage,
 *       "Dashboard": Dashboard,
 *       "Settings": Settings,
 *   }
 *   
 *   export const pagesConfig = {
 *       mainPage: "HomePage",
 *       Pages: PAGES,
 *   };
 * 
 * Example with Layout (wraps all pages):
 *
 *   import Home from './pages/Home';
 *   import Settings from './pages/Settings';
 *   import __Layout from './Layout.jsx';
 *
 *   export const PAGES = {
 *       "Home": Home,
 *       "Settings": Settings,
 *   }
 *
 *   export const pagesConfig = {
 *       mainPage: "Home",
 *       Pages: PAGES,
 *       Layout: __Layout,
 *   };
 *
 * To change the main page from HomePage to Dashboard, use find_replace:
 *   Old: mainPage: "HomePage",
 *   New: mainPage: "Dashboard",
 *
 * The mainPage value must match a key in the PAGES object exactly.
 */
import Battles from './pages/Battles';
import Create from './pages/Create';
import Dashboard from './pages/Dashboard';
import Explore from './pages/Explore';
import Groups from './pages/Groups';
import Home from './pages/Home';
import Landing from './pages/Landing';
import MySongs from './pages/MySongs';
import Plans from './pages/Plans';
import Playlists from './pages/Playlists';
import Presets from './pages/Presets';
import Safety from './pages/Safety';
import Settings from './pages/Settings';
import __Layout from './Layout.jsx';


export const PAGES = {
    "Battles": Battles,
    "Create": Create,
    "Dashboard": Dashboard,
    "Explore": Explore,
    "Groups": Groups,
    "Home": Home,
    "Landing": Landing,
    "MySongs": MySongs,
    "Plans": Plans,
    "Playlists": Playlists,
    "Presets": Presets,
    "Safety": Safety,
    "Settings": Settings,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
    Layout: __Layout,
};